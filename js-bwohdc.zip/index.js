// Import stylesheets
import './style.css';

// Write Javascript code!
const appDiv = document.getElementById('app');
const outputDiv = document.getElementById('app');
appDiv.innerHTML = `<h1>Mutiples of 3,5 and 15</h1>`;

let ans = '';
for (let i = 1; i <= 100; i++) {
  if (i % 3 == 0 && i % 5 == 0) ans = 'amazon';
  else if (i % 3 == 0) ans = 'google';
  else if (i % 5 == 0) ans = 'facebook';
  else ans = i;
  document
    .getElementById('output')
    .insertAdjacentHTML('beforeend', `<h3>${ans}</h3>`);
  //outputDiv.innerHTML += `${ans}\n`;
}
